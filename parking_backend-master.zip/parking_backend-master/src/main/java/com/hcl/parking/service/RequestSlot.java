package com.hcl.parking.service;

public interface RequestSlot {

}
