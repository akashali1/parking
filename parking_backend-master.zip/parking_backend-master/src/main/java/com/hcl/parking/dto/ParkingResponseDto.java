package com.hcl.parking.dto;

public class ParkingResponseDto {

}
