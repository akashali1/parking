package com.hcl.parking.repository;

public interface ParkingRepository {

}
